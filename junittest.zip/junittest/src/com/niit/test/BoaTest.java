package com.niit.test;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class BoaTest {

	String food1=null;
	String food2=null;
	private Boa jen;
	private Boa ken;
	Integer one=0;
	int two=0;
	
	
	@Before
	public void setUp()
	{
		 jen = new  Boa("jenifer",2,"granola bars");
		 ken = new  Boa("kenneth",3,"banana");
		 this.food1=jen.getFavouriteFood();
		 this.food2=ken.getFavouriteFood();
		 this.one=jen.getLength();
		 this.two=ken.getLength();
	}
	
	public boolean isEqualLenght(int cageLength){
        
        boolean result = false;
        if(one==cageLength){
            result = true;
        }
        return result;
    }
	
	
	@Test
	public void testIsHealthy() {
		
		System.out.println("test for isHealthy");
		 assertTrue(food1.equals("granola bars"));
	}

	@Test
	public void testFitsInCage() {
		System.out.println("test for cage length");
        assertTrue(one.equals(2));
	}
	
	@Test
	public void lengthInInches()
	{
		assertEquals(jen.lengthInInches(),24);
		assertEquals(ken.lengthInInches(),36);
	}

}
